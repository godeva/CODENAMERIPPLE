package le.ripp.ripple;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Comment {

    private String body;
    private final String id;

    private final String userID;
    private boolean anonymous;
    private final Date posted;

    private final List<Comment> children;

    public Comment(String body, String userID, boolean anonymous) {
        this.body 		= body;
        this.id			= Etc.generateID();
        this.userID 	= userID;
        this.anonymous 	= anonymous;
        this.posted 	= new Date();
        this.children 	= new ArrayList<Comment>();
    }

    //made public for testing purposes
    public Comment(String body, String id, String userID, boolean anonymous, Date posted, List<Comment> children) {
        super();
        this.body = body;
        this.id = id;
        this.userID = userID;
        this.anonymous = anonymous;
        this.posted = posted;
        this.children = children;
    }

    public Post parseFromXML(Object XML) {
        return null;

        //TODO: implement
    }

    public String getBody() {
        return body;
    }

    public String getId() {
        return id;
    }

    public String getUserID() {
        return userID;
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public Date getPosted() {
        return posted;
    }

    public List<Comment> getChildren() {
        return children;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }
}

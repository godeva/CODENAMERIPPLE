package le.ripp.ripple;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    protected TextView usernameTV;
    protected CustomPostAdapter postFeedAdapter;
    protected String thisUser;
    protected Networking network;
    protected NavigationView navigationView;
    protected SwipeRefreshLayout postFeedSwipeRefreshLayout;
    protected Toolbar toolbar;
    protected ArrayList<Post> relPosts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_feed_main_activity);

        network = new Networking(this);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        setUpFAB();
        setUpSwipeRefresh();
        setUpNavDrawer();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        SharedPreferences settings = getApplicationContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
        thisUser = settings.getString("USER_NAME",null);

        relPosts = getRelPosts();

        RecyclerView postFeedRV = (RecyclerView)findViewById(R.id.rvPostFeed);
        postFeedRV.addItemDecoration(new DividerItemDecoration(20));
        LinearLayoutManager postFeedLLM = new LinearLayoutManager(this);
        postFeedRV.setLayoutManager(postFeedLLM);
        postFeedAdapter = new CustomPostAdapter(relPosts);
        postFeedRV.setAdapter(postFeedAdapter);
    }

    protected void onResume(){
        super.onResume();
        relPosts = getRelPosts();
        postFeedAdapter.notifyDataSetChanged();

        navigationView.getMenu().getItem(0).setChecked(true);
        Log.i("TEST", "resume resume resume");
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {

            finish();
            //super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        //populate navigation drawer
        usernameTV = (TextView)findViewById(R.id.tvUsername);
        usernameTV.setText(thisUser);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent i = new Intent(this, SettingsActivity.class);
            startActivity(i);
            return true;
        }else if(id == R.id.action_logout){
            SharedPreferences settings = getApplicationContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("USER_NAME",null);
            editor.commit();
            Intent i = new Intent(this, LoginPage.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            //i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            this.startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_feed) {
            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            if (drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START);
            }
        } else if (id == R.id.nav_profile) {
            navigationView.getMenu().getItem(1).setChecked(false);
            Intent intent = new Intent(MainActivity.this, UserProfile.class);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void setUpFAB(){
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.btWritePost);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();*/
                Intent intent = new Intent(MainActivity.this, PostCompose.class);
                startActivity(intent);
            }
        });
    }

    private void setUpSwipeRefresh() {
        postFeedSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.postFeedSwipeRefreshLayout);
        postFeedSwipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Refresh items
                refreshItems();
            }
        });
        postFeedSwipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorPrimary));

    }

    private void refreshItems() {
        // Load items
        relPosts = getRelPosts();

        // Load complete
        onItemsLoadComplete();
    }

    private void onItemsLoadComplete() {
        // Update the adapter and notify data set changed
        postFeedAdapter.notifyDataSetChanged();

        // Stop refresh animation
        postFeedSwipeRefreshLayout.setRefreshing(false);
    }

    private void setUpNavDrawer(){
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
    }


    public ArrayList<Post> getRelPosts(){

        try {
            return network.getTopPosts(new User(thisUser, "","PASSWORD"));
        } catch (Exception e) {
            e.printStackTrace();
            ArrayList<Post> posts = new ArrayList<>();
            Post test1 = new Post("This post is very interesting, click on it.", "I lied, it is not interesting.", "Al-B",2,20);
            Post test2 = new Post("I like goats.", "Just kidding, this is the basket fan page.", "Don",20,2);
            Post test3 = new Post("Yo, I almost burnt down the room.", "jk, get it? Jack Kirwan? lolz", "Jack-Dog",2,50);
            Post test4 = new Post("Man, this Daka food is awful.  Have you seen their fake asian food? It isn't even food! OMGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG!",
                    "Daka. Can't stand it. Really.  It's awful. I promise. You'll see. Or not. I don't care.", "Marco",3000,2);
            posts.add(test1);
            posts.add(test2);
            posts.add(test3);
            posts.add(test4);
            posts.add(test1);
            posts.add(test2);
            posts.add(test3);
            posts.add(test4);
            posts.add(test1);
            posts.add(test2);
            posts.add(test3);
            posts.add(test4);
            posts.add(test1);
            posts.add(test2);
            posts.add(test3);
            posts.add(test4);
            posts.add(test1);
            posts.add(test2);
            posts.add(test3);
            posts.add(test4);
            posts.add(test1);
            posts.add(test2);
            posts.add(test3);
            posts.add(test4);
            posts.add(test4);
            return posts;
        }
    }

    public void myUpClickHandler(View v)
    {
        //get the row the clicked button is in
        LinearLayout vwParentRow = (LinearLayout)v.getParent();
        RecyclerView rvPosts = (RecyclerView)vwParentRow.getParent().getParent().getParent().getParent();
        Post post = postFeedAdapter.getItem(rvPosts.getChildLayoutPosition((CardView) vwParentRow.getParent().getParent().getParent()));

        ToggleButton upArrow = (ToggleButton)vwParentRow.getChildAt(0);
        ToggleButton downArrow = (ToggleButton)vwParentRow.getChildAt(2);
        TextView score = (TextView)vwParentRow.getChildAt(1);

        int numScore = Integer.parseInt(score.getText().toString());

        try {
            if (downArrow.isChecked() && upArrow.isChecked()) {
                downArrow.setChecked(false);
                numScore += 2;
                network.upVote(Integer.parseInt(post.getID()), thisUser, true);
                network.upVote(Integer.parseInt(post.getID()), thisUser, true);
            } else if (upArrow.isChecked()) {
                numScore++;
                network.upVote(Integer.parseInt(post.getID()), thisUser, true);
            } else {
                numScore--;
                network.upVote(Integer.parseInt(post.getID()), thisUser, false);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        score.setText(String.valueOf(numScore));
    }

    public void myDownClickHandler(View v)
    {
        //get the row the clicked button is in
        LinearLayout vwParentRow = (LinearLayout)v.getParent();
        RecyclerView rvPosts = (RecyclerView)vwParentRow.getParent().getParent().getParent().getParent();
        Post post = postFeedAdapter.getItem(rvPosts.getChildLayoutPosition((CardView) vwParentRow.getParent().getParent().getParent()));

        ToggleButton upArrow = (ToggleButton)vwParentRow.getChildAt(0);
        ToggleButton downArrow = (ToggleButton)vwParentRow.getChildAt(2);
        TextView score = (TextView)vwParentRow.getChildAt(1);

        int numScore = Integer.parseInt(score.getText().toString());
        try {
            if (downArrow.isChecked() && upArrow.isChecked()) {
                upArrow.setChecked(false);
                numScore -= 2;
                network.upVote(Integer.parseInt(post.getID()), thisUser, false);
                network.upVote(Integer.parseInt(post.getID()), thisUser, false);
            } else if (downArrow.isChecked()) {
                numScore--;
                network.upVote(Integer.parseInt(post.getID()), thisUser, false);
            } else {
                numScore++;
                network.upVote(Integer.parseInt(post.getID()), thisUser, true);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        score.setText(String.valueOf(numScore));
    }

}

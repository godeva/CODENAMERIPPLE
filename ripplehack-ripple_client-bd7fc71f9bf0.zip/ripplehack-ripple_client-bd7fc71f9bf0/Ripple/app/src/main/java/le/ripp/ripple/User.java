package le.ripp.ripple;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class User {

    private final String username;
    private final String id;
    private final Date joined;
    private String email;
    private String passHash; //no idea if this should be here or not

    private int postKarma;
    private int commentKarma;

    final List<String> connectedIPs;

    public User(String username, String email, String passHash) {
        this.username		= username;
        this.id				= Etc.generateID();
        this.joined 		= new Date();
        this.email 			= email;
        this.passHash 		= passHash;
        this.postKarma 		= 0;
        this.commentKarma 	= 0;
        this.connectedIPs 	= new ArrayList<String>();
    }

    public String getUsername() {
        return username;
    }

    public String getId() {
        return id;
    }

    public Date getJoined() {
        return joined;
    }

    public String getEmail() {
        return email;
    }

    public String getPassHash() {
        return passHash;
    }

    public int getPostKarma() {
        return postKarma;
    }

    public int getCommentKarma() {
        return commentKarma;
    }

    public List<String> getConnectedIPs() {
        return connectedIPs;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassHash(String passHash) {
        this.passHash = passHash;
    }

    public void setPostKarma(int postKarma) {
        this.postKarma = postKarma;
    }

    public void setCommentKarma(int commentKarma) {
        this.commentKarma = commentKarma;
    }


}
package le.ripp.ripple;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;

public class UserProfile extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, AdapterView.OnItemClickListener{
    CustomPostOwnerAdapter postOwnerAdapter;
    CustomCommentOwnerAdapter commentOwnerAdapter;
    User thisUser;
    NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_profile_main_activity);

        setUpNavBar();

        displayUsersPosts(null);

        thisUser = getCurrentUser();

        TextView userNameTV = (TextView)findViewById(R.id.tvUsernameProfile);
        TextView maxPostKarmaTV = (TextView)findViewById(R.id.tvMaxPostKarma);
        TextView maxCommentKarmaTV = (TextView)findViewById(R.id.tvMaxCommentKarma);

        userNameTV.setText(thisUser.getUsername());
        maxPostKarmaTV.setText("Post: " + String.valueOf(thisUser.getPostKarma()));
        maxCommentKarmaTV.setText("Comment: " + String.valueOf(thisUser.getCommentKarma()));
    }

    protected void onStart(){
        super.onStart();
    }

    protected void onResume(){
        super.onResume();
        navigationView.getMenu().getItem(1).setChecked(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        //populate navigation drawer text
        TextView usernameTV = (TextView)findViewById(R.id.tvUsername);
        usernameTV.setText(thisUser.getUsername());
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent i = new Intent(this, SettingsActivity.class);
            startActivity(i);
            return true;
        }else if(id == R.id.action_logout){
            SharedPreferences settings = getApplicationContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("USER_NAME",null);
            editor.commit();
            Intent i = new Intent(this, LoginPage.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            this.startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }

    private void setUpNavBar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_user_profile);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_feed) {
            finish();
        } else if (id == R.id.nav_profile) {
            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            if (drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START);
            }
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private ArrayList<Post> getUserPosts(){
        //get posts from logged in user
        ArrayList<Post> posts = new ArrayList<>();
        Post test1 = new Post("This post is very interesting, click on it.", "I lied, it is not interesting.", "Al-B",2,20);
        posts.add(test1);
        posts.add(test1);
        posts.add(test1);
        return posts;
    }

    private ArrayList<Comment> getUserComments(){
        ArrayList<Comment> comments = new ArrayList<>();
        return comments;
    }

    private User getCurrentUser(){
        SharedPreferences settings = getApplicationContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
        String userName = settings.getString("USER_NAME",null);

        User user = new User(userName,"email","PASSWORD");
        user.setCommentKarma(57);
        user.setPostKarma(39);
        return user;
    }

    private void setUpListViewPosts(){
        ArrayList<Post> postArray = getUserPosts();
        postOwnerAdapter = new CustomPostOwnerAdapter(this, postArray);
        ListView postFeedlv = (ListView)findViewById(R.id.lvUserPostsOrComments);
        postFeedlv.setAdapter(postOwnerAdapter);
        postFeedlv.setOnItemClickListener(UserProfile.this);
    }

    private void setUpListViewComments(){
        ArrayList<Comment> commentArray = getUserComments();
        commentOwnerAdapter = new CustomCommentOwnerAdapter(this, commentArray);
        ListView commentFeedlv = (ListView)findViewById(R.id.lvUserPostsOrComments);
        commentFeedlv.setAdapter(commentOwnerAdapter);
        commentFeedlv.setOnItemClickListener(UserProfile.this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Post currentPost = (Post)parent.getItemAtPosition(position);
        Intent intent = new Intent(UserProfile.this, PostDisplay.class);
        intent.putExtra("TITLE", currentPost.getTitle());
        intent.putExtra("BODY", currentPost.getBody());
        intent.putExtra("AUTHOR", currentPost.getUsername());
        intent.putExtra("SCORE", currentPost.getScore());
        startActivity(intent);
    }

    public void goToMap(View v){
        //get the row the clicked button is in
        RelativeLayout vwParentRow = (RelativeLayout)v.getParent();
        ListView lvUserPosts = (ListView)vwParentRow.getParent();
        String postID = postOwnerAdapter.getItem(lvUserPosts.getPositionForView(vwParentRow)).getID();

        Intent intent = new Intent(UserProfile.this, MapsPost.class);
        intent.putExtra("POST_ID", postID);
        startActivity(intent);
    }

    public void displayUsersPosts(View view){
        Button postsBT = (Button)findViewById(R.id.btPosts);
        Button commentsBT = (Button)findViewById(R.id.btComments);
        postsBT.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        commentsBT.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        //postsBT.setPressed(true);
        //commentsBT.setPressed(false);
        setUpListViewPosts();
    }

    public void displayUsersComments(View view){
        Button postsBT = (Button)findViewById(R.id.btPosts);
        Button commentsBT = (Button)findViewById(R.id.btComments);
        commentsBT.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        postsBT.setBackgroundColor(getResources().getColor(android.R.color.transparent));
        //postsBT.setPressed(false);
        //commentsBT.setPressed(true);
        setUpListViewComments();
    }
}

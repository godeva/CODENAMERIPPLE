package le.ripp.ripple;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;

public class PostCompose extends AppCompatActivity {

    CheckBox anonCB;
    EditText postET;
    EditText titleET;
    Networking network;
    String thisUser;
    Context c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_compose_activity);
        anonCB=(CheckBox)findViewById(R.id.cbAnon);
        postET=(EditText)findViewById(R.id.etPostText);
        titleET=(EditText)findViewById(R.id.etPostTitle);
        network = new Networking(this);

        c = this.getApplicationContext();

        SharedPreferences settings = c.getSharedPreferences("USER", Context.MODE_PRIVATE);
        thisUser = settings.getString("USER_NAME",null);
    }

    public void postMessage(View view){
        new PostPostTask().execute(postET.getText().toString(),
                titleET.getText().toString());
        finish();
    }

    private class PostPostTask extends AsyncTask<String, Void, Boolean> {

        @Override
        protected Boolean doInBackground(String ... args) {
            //boolean anon = anonCB.isChecked();
            String postText = args[0]; //postET.getText().toString();
            String titleText = args[1]; //titleET.getText().toString();
            if(!(postText.length()==0) && !(titleText.length()==0)) {
                try {
                    return Boolean.valueOf(network.postPost(new Post(titleText, postText, thisUser, 0, 0)));
                } catch (XmlPullParserException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return Boolean.FALSE;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            String s;
            if(result.booleanValue())
                s = getString(R.string.post_notification);
            else
                s = "Failed to post...";
            Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
        }
    }
}

package le.ripp.ripple;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.List;

public class PostDisplay extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    String thisUser;
    NavigationView navigationView;
    LinearLayout commentLayoutLLV;
    Post thisPost;
    Networking networking;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_display_main_activity);

        networking = new Networking(getApplicationContext());

        Bundle extras = getIntent().getExtras();
        String postID = extras.getString("POST_ID");
        thisPost = /*networking.*/getPost(postID);

        String title = extras.getString("TITLE");
        String body = extras.getString("BODY");
        String author = extras.getString("AUTHOR");
        int numScore = extras.getInt("SCORE");


        TextView postTitleTV = (TextView) findViewById(R.id.tvPostTitle);
        TextView postUserTV = (TextView) findViewById(R.id.tvPostUser);
        TextView postBodyTV = (TextView) findViewById(R.id.tvPostBody);
        TextView score = (TextView) findViewById(R.id.tvScore);

        score.setText(String.valueOf(numScore));
        postTitleTV.setText(title);
        postUserTV.setText(author);
        postBodyTV.setText(body);

        setUpNavBar();

        SharedPreferences settings = getApplicationContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
        thisUser = settings.getString("USER_NAME",null);

        commentLayoutLLV = (LinearLayout)findViewById(R.id.llVPostDisplay);
        List<Comment> comments = thisPost.getComments();
        populateCommentLayout(commentLayoutLLV,comments);
    }

    private void populateCommentLayout(LinearLayout parentLayout, List<Comment> comments){
        if(comments != null){
            for(int i=0;i<comments.size();i++){
                Comment c = comments.get(i);
                View commentLayout = LayoutInflater.from(this).inflate(R.layout.post_display_comment_item, parentLayout, false);

                TextView commentUserTV = (TextView)commentLayout.findViewById(R.id.tvCommentUsername);
                TextView commentBodyTV = (TextView)commentLayout.findViewById(R.id.tvCommentBody);
                TextView commentScoreTV = (TextView)commentLayout.findViewById(R.id.tvCommentScore);
                LinearLayout commentCommentLayoutLLV = (LinearLayout)commentLayout.findViewById(R.id.llvCommentItemChildComments);


                commentUserTV.setText(c.getUserID());
                commentBodyTV.setText(c.getBody());
                //commentScoreTV.setText(c.getScore());
                populateCommentLayout(commentCommentLayoutLLV,c.getChildren());

                parentLayout.addView(commentLayout);
            }
        }
    }

    private Post getPost(String id){
        ArrayList<Comment> comments = new ArrayList<>();
        Comment c = new Comment("This is a test comment.","User Name",false);
        comments.add(c);
        comments.add(c);
        comments.add(c);
        Comment pC = new Comment("This comment has been replied to.","comment id", "test user", false,
                null, (ArrayList<Comment>)comments.clone());
        comments.add(pC);
        comments.add(pC);
        Comment pC2 = new Comment("This comment has been replied to multiple times.","comment id", "test user", false,
                null, (ArrayList<Comment>)comments.clone());
        comments.add(pC2);
        comments.add(pC2);
        Comment pC3 = new Comment("This comment has been replied to many times.","comment id", "test user", false,
                null, (ArrayList<Comment>)comments.clone());
        comments.add(pC3);
        Post p = new Post(null,null,null,null,null,comments,0,0);
        return p;
    }

    protected void onResume(){
        super.onResume();
        navigationView.getMenu().getItem(0).setChecked(false);
        navigationView.getMenu().getItem(1).setChecked(false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);

        //populate navigation drawer text
        TextView usernameTV = (TextView)findViewById(R.id.tvUsername);
        usernameTV.setText(thisUser);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent i = new Intent(this, SettingsActivity.class);
            startActivity(i);
            return true;
        }else if(id == R.id.action_logout){
            SharedPreferences settings = getApplicationContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("USER_NAME",null);
            editor.commit();
            Intent i = new Intent(this, LoginPage.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            this.startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }

    private void setUpNavBar(){
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_post_display);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_feed) {
            finish();
        } else if (id == R.id.nav_profile) {
            Intent intent = new Intent(PostDisplay.this, UserProfile.class);
            startActivity(intent);
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void upClick(View view){
        ToggleButton upArrow = (ToggleButton)findViewById(R.id.btUpVote);
        ToggleButton downArrow = (ToggleButton)findViewById(R.id.btDownVote);
        TextView score = (TextView)findViewById(R.id.tvScore);

        int numScore = Integer.parseInt(score.getText().toString());

        if(downArrow.isChecked()&&upArrow.isChecked()){
            downArrow.setChecked(false);
            numScore+=2;
        }else if(upArrow.isChecked()){
            numScore++;
        }
        else{
            numScore--;
        }
        score.setText(String.valueOf(numScore));
    }

    public void downClick(View view){
        ToggleButton upArrow = (ToggleButton)findViewById(R.id.btUpVote);
        ToggleButton downArrow = (ToggleButton)findViewById(R.id.btDownVote);
        TextView score = (TextView)findViewById(R.id.tvScore);

        int numScore = Integer.parseInt(score.getText().toString());
        if(downArrow.isChecked()&&upArrow.isChecked()){
            upArrow.setChecked(false);
            numScore-=2;
        }else if(downArrow.isChecked()){
            numScore--;
        }else{
            numScore++;
        }
        score.setText(String.valueOf(numScore));
    }

    public void replyToComment(View v)
    {
        /*//get the row the clicked button is in
        LinearLayout vwParentRow = (LinearLayout)v.getParent();
        RecyclerView rvPosts = (RecyclerView)vwParentRow.getParent().getParent().getParent().getParent();
        Post post = postFeedAdapter.getItem(rvPosts.getChildLayoutPosition((CardView) vwParentRow.getParent().getParent().getParent()));

        ToggleButton upArrow = (ToggleButton)vwParentRow.getChildAt(0);
        ToggleButton downArrow = (ToggleButton)vwParentRow.getChildAt(2);
        TextView score = (TextView)vwParentRow.getChildAt(1);

        int numScore = Integer.parseInt(score.getText().toString());

        try {
            if (downArrow.isChecked() && upArrow.isChecked()) {
                downArrow.setChecked(false);
                numScore += 2;
                network.upVote(Integer.parseInt(post.getID()), thisUser, true);
                network.upVote(Integer.parseInt(post.getID()), thisUser, true);
            } else if (upArrow.isChecked()) {
                numScore++;
                network.upVote(Integer.parseInt(post.getID()), thisUser, true);
            } else {
                numScore--;
                network.upVote(Integer.parseInt(post.getID()), thisUser, false);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        score.setText(String.valueOf(numScore));*/
    }
}

package le.ripp.ripple;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Post {

    private final String title;
    private final String body;
    private final String id;

    private final String username;
    private final Date posted;

    private final List<Comment> comments;

    private int upvotes;
    private int downvotes;

    public Post(String title, String body, String username,int upvotes, int downvotes) {
        this.title 		= title;
        this.body 		= body;
        this.id			= Etc.generateID();
        this.username   = username;
        this.posted 	= new Date();
        this.upvotes 	= upvotes;
        this.downvotes 	= downvotes;
        this.comments 	= new ArrayList<Comment>();
    }

    Post(String title, String body, String id, String username, Date posted, //used only for parsing XML
                 List<Comment> comments, int upvotes, int downvotes) {
        super();
        this.title = title;
        this.body = body;
        this.id = id;
        this.username = username;
        this.posted = posted;
        this.comments = comments;
        this.upvotes = upvotes;
        this.downvotes = downvotes;
    }

    public Post parseFromXML(Object XML) {
        return null;

        //TODO: implement
    }

    public String getTitle() {
        return title;
    }

    public String getBody() {
        return body;
    }

    public String getUsername() {
        return username;
    }

    public String getID() {
        return id;
    }

    public Date getPosted() {
        return posted;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public int getScore() {
        return upvotes - downvotes;
    }
}

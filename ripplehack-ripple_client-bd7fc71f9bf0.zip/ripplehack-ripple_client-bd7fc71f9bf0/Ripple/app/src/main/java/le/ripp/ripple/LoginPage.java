package le.ripp.ripple;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.transition.Fade;
import android.transition.Slide;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginPage extends AppCompatActivity {

    protected TextView mSignUpTextView;
    protected String thisUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.login_page_activity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mSignUpTextView = (TextView)findViewById(R.id.tvSignUpLogin);
        mSignUpTextView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginPage.this, SignUpActivity.class);
                startActivity(intent);
                }
        });
    }

    protected void onResume(){
        super.onResume();

        SharedPreferences settings = getApplicationContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
        try{
            thisUser = settings.getString("USER_NAME",null);
            if(thisUser.length()>0) {
                //the user is already logged in
                logIn(null);
            }
        }catch(NullPointerException e){
            //log in
        }
    }

    protected void onStop(){
        super.onStop();
        /*EditText usernameET = (EditText) findViewById(R.id.etUsernameLogin);
        EditText passwordET = (EditText) findViewById(R.id.etPasswordLogin);
        usernameET.setText("");
        passwordET.setText("");*/
    }

    public void logIn(View v) {
        //placeholder until login is implemented...
        //assume that the user authenticates...

        if(v==null){
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            //i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            this.startActivity(i);
        }else {

            EditText usernameET = (EditText) findViewById(R.id.etUsernameLogin);
            EditText passwordET = (EditText) findViewById(R.id.etPasswordLogin);
            if (usernameET.getText().toString().length() == 0) {
                Toast.makeText(getApplicationContext(), "Enter your username", Toast.LENGTH_SHORT).show();
            } else if (passwordET.getText().toString().length() == 0) {
                Toast.makeText(getApplicationContext(), "Enter your password", Toast.LENGTH_SHORT).show();
            } else {
                thisUser = usernameET.getText().toString();
                SharedPreferences settings = v.getContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = settings.edit();
                editor.putString("USER_NAME", thisUser);
                editor.commit();

                //PreferenceManager.getDefaultSharedPreferences(this).edit().putBoolean("pref_first_run", false);
                Intent i = new Intent(this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                //i.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                this.startActivity(i);
            }
        }
    }

}

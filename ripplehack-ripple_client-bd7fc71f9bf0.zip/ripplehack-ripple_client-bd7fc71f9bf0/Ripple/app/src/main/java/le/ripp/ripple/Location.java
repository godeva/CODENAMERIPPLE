package le.ripp.ripple;


public class Location {

    final double lattitude;
    final double longitude;

    public Location(double lattitude, double longitude) {
        this.lattitude = lattitude;
        this.longitude = longitude;
    }

    public double getDistanceTo(Location loc1) {
        return Math.sqrt(Math.pow(lattitude - loc1.lattitude, 2) + Math.pow(longitude - loc1.longitude, 2));
    }
}

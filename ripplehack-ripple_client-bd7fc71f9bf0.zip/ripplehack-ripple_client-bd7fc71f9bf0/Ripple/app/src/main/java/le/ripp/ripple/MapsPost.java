package le.ripp.ripple;

import android.graphics.Color;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;

public class MapsPost extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maps_post_activity);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        setUpMap();
    }

    private void setUpMap() {
        //request coordinates
        double point1Lat = 10;
        double point1Lng = 0;
        double point2Lat = 0;
        double point2Lng = 0;
        double point3Lat = 10;
        double point3Lng = 10;
        double point4Lat = 0;
        double point4Lng = 10;

        double lat = (point1Lat + point2Lat + point3Lat + point4Lat) / 4;
        double lng = (point1Lng + point2Lng + point3Lng + point4Lng) / 4;
        LatLng position = new LatLng(lat, lng);

        double diffLat = getMaxLat(point1Lat,point2Lat,point3Lat,point4Lat)-getMinLat(point1Lat, point2Lat, point3Lat, point4Lat);
        double diffLng = getMaxLng(point1Lng, point2Lng, point3Lng, point4Lng)-getMinLat(point1Lng, point2Lng, point3Lng, point4Lng);

        double diff = Math.max(diffLat,diffLng);

        float zoomLevel = (float)(7);
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(position));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(position, zoomLevel));

        PolygonOptions rectOptions = new PolygonOptions()
                .add(new LatLng(point1Lat, point1Lng),
                        new LatLng(point2Lat, point2Lng),
                        new LatLng(point4Lat, point4Lng),
                        new LatLng(point3Lat, point3Lng));

        rectOptions.strokeColor(Color.argb(135, 140, 255, 140));
        rectOptions.fillColor(Color.argb(128, 128, 255, 128));
        rectOptions.geodesic(true);

        Polygon polygon = mMap.addPolygon(rectOptions);

    }

    private double getMinLat(double p1, double p2, double p3, double p4) {
        double minLat=p1;
        if(p2<minLat)
            minLat=p2;
        if(p3<minLat)
            minLat=p3;
        if(p4<minLat)
            minLat=p4;
        return minLat;
    }

    private double getMinLng(double p1, double p2, double p3, double p4) {
        double minLng=p1;
        if(p2<minLng)
            minLng=p2;
        if(p3<minLng)
            minLng=p3;
        if(p4<minLng)
            minLng=p4;
        return minLng;
    }

    private double getMaxLat(double p1, double p2, double p3, double p4) {
        double maxLat=p1;
        if(p2>maxLat)
            maxLat=p2;
        if(p3>maxLat)
            maxLat=p3;
        if(p4>maxLat)
            maxLat=p4;
        return maxLat;
    }

    private double getMaxLng(double p1, double p2, double p3, double p4) {
        double maxLng=p1;
        if(p2>maxLng)
            maxLng=p2;
        if(p3>maxLng)
            maxLng=p3;
        if(p4>maxLng)
            maxLng=p4;
        return maxLng;
    }


}

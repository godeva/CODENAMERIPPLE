package le.ripp.ripple;

import android.os.Bundle;
import android.preference.PreferenceActivity;

/**
 * Created by zoraver on 1/23/16.
 */

public class SettingsActivity extends PreferenceActivity{

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.app_settings);
    }
}

package le.ripp.ripple;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;

/**
 * Created by brian_000 on 1/23/2016.
 */
public class CustomPostAdapter extends RecyclerView.Adapter<CustomPostAdapter.PostViewHolder>{
    protected ArrayList<Post> posts;

    public CustomPostAdapter(ArrayList<Post> posts){
        this.posts=posts;
    }

    public Post getItem(int position){
        return posts.get(position);
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    @Override
    public PostViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.post_feed_item, viewGroup, false);
        PostViewHolder pvh = new PostViewHolder(v);
        return pvh;
    }

    @Override
    public void onBindViewHolder(PostViewHolder postViewHolder, int i) {
        postViewHolder.postTitleTV.setText(posts.get(i).getTitle());
        postViewHolder.postUserTV.setText(posts.get(i).getUsername());
        postViewHolder.scoreTV.setText(String.valueOf(posts.get(i).getScore()));

        postViewHolder.currentPost=posts.get(i);
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    public static class PostViewHolder extends RecyclerView.ViewHolder {
        View view;
        Post currentPost;
        TextView postTitleTV;
        TextView postUserTV;
        TextView scoreTV;
        ToggleButton UpBT;
        ToggleButton DownBT;

        PostViewHolder(View itemView){
            super(itemView);
            postTitleTV = (TextView)itemView.findViewById(R.id.tvPostTitle);
            postUserTV = (TextView)itemView.findViewById(R.id.tvPostUser);
            scoreTV = (TextView)itemView.findViewById(R.id.tvScore);
            UpBT = (ToggleButton)itemView.findViewById(R.id.btUpVote);
            DownBT = (ToggleButton)itemView.findViewById(R.id.btDownVote);

            view = itemView;
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(), PostDisplay.class);
                    intent.putExtra("TITLE", currentPost.getTitle());
                    intent.putExtra("BODY", currentPost.getBody());
                    intent.putExtra("AUTHOR", currentPost.getUsername());
                    intent.putExtra("SCORE", currentPost.getScore());
                    intent.putExtra("POST_ID",currentPost.getID());
                    v.getContext().startActivity(intent);
                }
            });
        }
    }
}

package le.ripp.ripple;

import java.util.Date;

public class Etc {

    public static long getMinsBetweenDates(Date d0, Date d1) {
        return Math.abs(d0.getTime() - d1.getTime());
    }

    public static String generateID() {
        return "TODO: GENERATE ID";
    }
}

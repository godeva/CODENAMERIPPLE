package le.ripp.ripple;

import android.content.Context;
import android.util.Xml;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


/**
 * Created by zoraver on 1/23/16.
 */
public class Networking {

    private final String ip = "24.34.222.248";
    private final int port = 51730;

    DocumentBuilder builder;
    Transformer transformer;
    Properties format;
    Context context;
    Geolocation geo;

    public Networking(Context context) {
        this.context = context;
        geo = new Geolocation(context);
        try {
            builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            transformer = TransformerFactory.newInstance().newTransformer();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
        }
        Properties format = new Properties();
        format.setProperty(OutputKeys.INDENT, "yes");
        format.setProperty(OutputKeys.METHOD, "xml");
        format.setProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
        format.setProperty(OutputKeys.VERSION, "1.0");
        format.setProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperties(format);
    }

    public Object requestFromServer(Document request) {

        try {
            Socket cs = new Socket(ip, port);

            new ObjectOutputStream(cs.getOutputStream()).writeObject(request);

            return new ObjectInputStream(cs.getInputStream()).readObject();

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    public XmlPullParser requestDocumentFromServer(Document request) {
        try {
            Socket cs = new Socket(ip, port);

            DOMSource domSource = new DOMSource(request.getDocumentElement());
            StreamResult result = new StreamResult(cs.getOutputStream());
            transformer.transform(domSource, result);

            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(cs.getInputStream(), null);
            return parser;

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (TransformerException e) {
            e.printStackTrace();
        }

        return null;
    }

    public JSONObject requestJSONFromServer(JSONObject request) {
        JSONObject response = null;

        try {
            Socket cs = new Socket(ip, port);
            InputStream is = cs.getInputStream();
            OutputStream os = cs.getOutputStream();

            PrintWriter pw = new PrintWriter(os);
            pw.println(request.toString());
            pw.flush();

            response = new JSONObject(new BufferedReader(new InputStreamReader(is)).readLine());

            is.close();
            os.close();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return response;
    }

    public String getIpAddress() throws IOException {
        URL myIP = new URL("http://icanhazip.com/");
        BufferedReader in = new BufferedReader(
                new InputStreamReader(myIP.openStream()));
        return in.readLine();
    }

    public boolean accoutUpdate(String email, String pswd, User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element aUpdateElement = document.createElement("acct-update");
        aUpdateElement.setAttribute("userID", user.getUsername());
        try {
            aUpdateElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        aUpdateElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        aUpdateElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        aUpdateElement.setAttribute("email", email);
        aUpdateElement.setAttribute("pswd", pswd);
        document.appendChild(aUpdateElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        int eventType = response.getEventType();

        while(eventType != XmlPullParser.END_DOCUMENT) {
            if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                for(int i = 0; i < response.getAttributeCount(); i++) {
                    if(response.getAttributeName(i) == "success") {
                        return Boolean.parseBoolean(response.getAttributeValue(i));
                    }
                }
            }
            eventType = response.next();
        }

        return false;
    }

    public boolean accountDelete(User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element aDeleteElement = document.createElement("acct-del");
        aDeleteElement.setAttribute("userID", user.getUsername());
        try {
            aDeleteElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        aDeleteElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        aDeleteElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        document.appendChild(aDeleteElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        int eventType = response.getEventType();

        while(eventType != XmlPullParser.END_DOCUMENT) {
            if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                for(int i = 0; i < response.getAttributeCount(); i++) {
                    if(response.getAttributeName(i) == "success") {
                        return Boolean.parseBoolean(response.getAttributeValue(i));
                    }
                }
            }
            eventType = response.next();
        }

        return false;
    }

    public boolean postPost(Post post) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element postElement = document.createElement("post");
        postElement.setAttribute("userID", post.getUsername());
        try {
            postElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        postElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        postElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        postElement.setAttribute("title", post.getTitle());
        postElement.setAttribute("body", post.getBody());
        document.appendChild(postElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }
        return false;
    }

    public boolean upVote(int postID, String username, boolean upVote) throws XmlPullParserException, IOException { //can actually downvote too...
        Document document = builder.newDocument();

        Element upVoteElement = document.createElement("vote");
        upVoteElement.setAttribute("userID", username);
        try {
            upVoteElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        upVoteElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        upVoteElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        upVoteElement.setAttribute("postID", String.valueOf(postID));
        upVoteElement.setAttribute("positive", String.valueOf(upVote));
        document.appendChild(upVoteElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }

        return false;
    }

    public boolean upVote(int postID, int commentID, String username, boolean upVote) throws XmlPullParserException, IOException { //can actually downvote too...
        Document document = builder.newDocument();

        Element upVoteElement = document.createElement("vote");
        upVoteElement.setAttribute("userID", username);
        try {
            upVoteElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        upVoteElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        upVoteElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        upVoteElement.setAttribute("postID", String.valueOf(postID));
        upVoteElement.setAttribute("commentID", String.valueOf(commentID));
        upVoteElement.setAttribute("positive", String.valueOf(upVote));
        document.appendChild(upVoteElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }
        return false;
    }

    public boolean deletePost(int postID, User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element deletePostElement = document.createElement("del-post");
        deletePostElement.setAttribute("userID", user.getUsername());
        try {
            deletePostElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        deletePostElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        deletePostElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        deletePostElement.setAttribute("postID", String.valueOf(postID));
        document.appendChild(deletePostElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }
        return false;
    }

    public boolean flag(int postID, String reason, User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element flagElement = document.createElement("flag");
        flagElement.setAttribute("userID", user.getUsername());
        try {
            flagElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        flagElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        flagElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        flagElement.setAttribute("postID", String.valueOf(postID));
        flagElement.setAttribute("reason", reason);
        document.appendChild(flagElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }
        return false;
    }

    public boolean flag(int postID, int commentID, String reason, User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element flagElement = document.createElement("flag");
        flagElement.setAttribute("userID", user.getUsername());
        try {
            flagElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        flagElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        flagElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        flagElement.setAttribute("postID", String.valueOf(postID));
        flagElement.setAttribute("commentID", String.valueOf(commentID));
        flagElement.setAttribute("reason", reason);
        document.appendChild(flagElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }

        return false;
    }

    public boolean addComment(int postID, String body, User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element commentElement = document.createElement("comment");
        commentElement.setAttribute("userID", user.getUsername());
        try {
            commentElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        commentElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        commentElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        commentElement.setAttribute("postID", String.valueOf(postID));
        commentElement.setAttribute("body", body);
        document.appendChild(commentElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }
        return false;
    }

    public boolean addComment(int postID, int commentID, String body, User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element commentElement = document.createElement("comment");
        commentElement.setAttribute("userID", user.getUsername());
        try {
            commentElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        commentElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        commentElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        commentElement.setAttribute("postID", String.valueOf(postID));
        commentElement.setAttribute("commentID", String.valueOf(commentID));
        commentElement.setAttribute("body", body);
        document.appendChild(commentElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }

        return false;
    }

    public boolean deleteComment(int postID, User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element deletePostElement = document.createElement("del-comment");
        deletePostElement.setAttribute("userID", user.getUsername());
        try {
            deletePostElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        deletePostElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        deletePostElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        deletePostElement.setAttribute("postID", String.valueOf(postID));
        document.appendChild(deletePostElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }
        return false;
    }

    public boolean deleteComment(int postID, int commentID, User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element deletePostElement = document.createElement("del-comment");
        deletePostElement.setAttribute("userID", user.getUsername());
        try {
            deletePostElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        deletePostElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        deletePostElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        deletePostElement.setAttribute("postID", String.valueOf(postID));
        deletePostElement.setAttribute("commentID", String.valueOf(commentID));
        document.appendChild(deletePostElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        if(response != null) {
            int eventType = response.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_TAG && response.getName() == "response") {
                    for(int i = 0; i < response.getAttributeCount(); i++) {
                        if(response.getAttributeName(i) == "success") {
                            return Boolean.parseBoolean(response.getAttributeValue(i));
                        }
                    }
                }
                eventType = response.next();
            }
        }
        return false;
    }

    public ArrayList<Post> getTopPosts(User user) throws XmlPullParserException, IOException {
        Document document = builder.newDocument();

        Element getElement = document.createElement("rel-posts");
        getElement.setAttribute("userID", user.getUsername());
        try {
            getElement.setAttribute("ip", String.valueOf(getIpAddress()));
        } catch (IOException e) {
            e.printStackTrace();
        }
        getElement.setAttribute("latitude", String.valueOf(geo.getLatitude()));
        getElement.setAttribute("longitude", String.valueOf(geo.getLongitude()));
        document.appendChild(getElement);

        XmlPullParser response = this.requestDocumentFromServer(document);
        ArrayList<Post> posts = new ArrayList<Post>();

        if(response != null) {
            int eventType = response.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG && response.getName() == "post") {
                    String title = "", body = "", username = "", userID = "", time = "", id = "";
                    int upVotes = 0;
                    for (int i = 0; i < response.getAttributeCount(); i++) {
                        switch (response.getAttributeName(i)) {
                            case "title":
                                title = response.getAttributeValue(i);
                                break;
                            case "body":
                                body = response.getAttributeValue(i);
                                break;
                            case "username":
                                username = response.getAttributeValue(i);
                                break;
                            case "id":
                                id = response.getAttributeValue(i);
                                break;
                            case "user":
                                userID = response.getAttributeValue(i);
                                break;
                            case "time":
                                time = response.getAttributeValue(i);
                                break;
                            case "upvotes":
                                upVotes = Integer.parseInt(response.getAttributeValue(i));
                                break;

                        }
                    }
                    Post post = new Post(title, body, id, username, Date.valueOf(time), new ArrayList<Comment>(), upVotes, 0);
                    posts.add(post);
                }
                eventType = response.next();
            }

        }

        return posts;
    }
}

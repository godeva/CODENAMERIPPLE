package le.ripp.ripple;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_activity);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    public void signUp(View v){
        EditText usernameET = (EditText)findViewById(R.id.etUsernameSignUp);
        EditText passwordET = (EditText)findViewById(R.id.etPasswordSignUp);
        EditText emailET = (EditText)findViewById(R.id.etEmailSignUp);
        if(usernameET.getText().toString().length()==0){
            Toast.makeText(getApplicationContext(), "Enter a username", Toast.LENGTH_SHORT).show();
        }
        else if(passwordET.getText().toString().length()==0){
            Toast.makeText(getApplicationContext(), "Enter a password", Toast.LENGTH_SHORT).show();
        }else if(emailET.getText().toString().length()==0){
            Toast.makeText(getApplicationContext(), "Enter an email", Toast.LENGTH_SHORT).show();
        }else {
            String thisUser = usernameET.getText().toString();
            SharedPreferences settings = v.getContext().getSharedPreferences("USER", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString("USER_NAME",thisUser);
            editor.commit();

            finish();
        }
    }
}



